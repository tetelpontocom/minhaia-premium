import UpsellPage from "../components/upsell-page"

export default function Page() {
  return <UpsellPage />
}
