import ThankYouPage from "../../components/thank-you-page"

export default function RegularPage() {
  return <ThankYouPage isPremium={false} />
}
