import ThankYouPremiumPage from "../../components/thank-you-premium-page"

export default function PremiumPage() {
  return <ThankYouPremiumPage />
}
