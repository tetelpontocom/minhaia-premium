import DownsellPage from "../../components/downsell-page"

export default function DownsellRoute() {
  return <DownsellPage />
}
