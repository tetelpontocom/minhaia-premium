import ThankYouPage from "../../components/thank-you-page"

export default function ObrigadoPage() {
  return <ThankYouPage isPremium={false} />
}
