import UpsellPage from "../components/upsell-page"
import PixelHelper from "../components/pixel-helper"

export default function Page() {
  return (
    <>
      <UpsellPage />
      <PixelHelper />
    </>
  )
}
