import MinhaIAPremium from "@/components/minha-ia-premium"

export default function Home() {
  return <MinhaIAPremium />
}
